from admin_tools.dashboard.dashboards import *
from admin_tools.dashboard.registry import *
