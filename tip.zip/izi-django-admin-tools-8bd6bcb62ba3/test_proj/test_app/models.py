from django.db import models

class Foo(models.Model):
    pass

class Bar(models.Model):
    pass